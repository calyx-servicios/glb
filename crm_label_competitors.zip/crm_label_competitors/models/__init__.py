# -*- coding: utf-8 -*-

from . import crm_label_competitors